from django.db import models
class Person(models.Model):
    f_name = models.CharField(max_length=30)
    l_name = models.CharField(max_length=30)
    e_id = models.CharField(max_length=30)
    
