from django.contrib import admin

from .models import Student
from .models import Employee
admin.site.register(Student)
admin.site.register(Employee)